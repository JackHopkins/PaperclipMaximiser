# Version 48

mcts_type:MCTSType.CHUNKED
system_prompt:
version:48
version_description:
n_parallel:4
max_steps:1000
skip_failures:False
model:ft:gpt-4o-mini-2024-07-18:paperplane-ai:mcts-pruned-masked:AYIViDdb
sampler_type:SamplerType.WEIGHTED_REWARD
max_conversation_length:30
logit_bias:{'15714': -100, '145968': -100, '27': -100, '20225': -100, '7032': -100}
temperature:0.7
compression_strength:None
max_conversation_length:30
adaptive_period:200
window_size:200
